package com.cg.mobshop.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.mobshop.dto.Mobiles;
@Repository
@Transactional
public class MobileDAOImpl implements MobileDAO {

	@PersistenceContext
	EntityManager entitymanager;
	
	
	public EntityManager getEntitymanager() {
		return entitymanager;
	}


	public void setEntitymanager(EntityManager entitymanager) {
		this.entitymanager = entitymanager;
	}


	public List<Mobiles> getAllMobiles(){
//		Query queryOne=entitymanager.createQuery("FROM Mobiles");
//		List<Mobiles> myList=queryOne.getResultList();
//				return myList;
		
		String str="select mobile from Mobiles mobile";
		TypedQuery<Mobiles> query=entitymanager.createQuery(str,Mobiles.class);
		return query.getResultList();
				
		
		
	}
}
